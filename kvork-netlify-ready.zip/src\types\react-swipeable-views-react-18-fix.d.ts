declare module "react-swipeable-views-react-18-fix";
